# Social_Media_App_Arya.soccial
ChatGPT said:  Arya.social is a full-stack social networking platform
